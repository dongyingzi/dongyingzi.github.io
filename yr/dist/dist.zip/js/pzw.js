var test = (function(){
	console.log('test');
})();
